<?
$sSectionName = "Образы";
$arDirProperties = Array(
   "title" => "Образы",
   "HIDE_LEFT_BLOCK" => "Y",
   "HIDE_LEFT_BLOCK_DETAIL" => "N"
);
?>