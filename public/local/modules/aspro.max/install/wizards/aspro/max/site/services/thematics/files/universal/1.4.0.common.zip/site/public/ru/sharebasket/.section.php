<?
$sSectionName = "Поделиться корзиной";
$arDirProperties = Array(
	"HIDE_LEFT_BLOCK" => "Y"
);
?>