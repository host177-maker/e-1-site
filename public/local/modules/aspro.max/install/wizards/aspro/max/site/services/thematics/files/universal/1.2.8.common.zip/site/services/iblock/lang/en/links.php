<?
$MESS["UF_SECTION_DESCR"] = "Краткое описание";
$MESS["UF_SECTION_TEMPLATE"] = "Шаблон списка товаров по умолчанию";
$MESS["UF_POPULAR"] = "Популярная категория";
$MESS["UF_CATALOG_ICON"] = "Иконка раздела";
$MESS["UF_OFFERS_TYPE"] = "Тип SKU";
$MESS["UF_TABLE_SIZES"] = "Таблица размеров";
$MESS["UF_ELEMENT_DETAIL"] = "Шаблон детальной страницы товара";
$MESS["UF_SECTION_BG_IMG"] = "Фоновая картинка в списке товаров";
$MESS["UF_SECTION_BG_DARK"] = "Темный текст в шапке при фоновом баннере";
$MESS["UF_SECTION_TIZERS"] = "Тизеры";
$MESS["UF_HELP_TEXT"] = "Примечание-подсказка";
$MESS["UF_MENU_BANNER"] = "Баннер раздела в меню";
$MESS["UF_REGION"] = "Регион";
$MESS["UF_MENU_LINK"] = "Ссылка пункта меню";
$MESS["UF_MEGA_MENU_LINK"] = "Ссылка при клике";
$MESS["UF_CATALOG_ICON"] = "Иконка";
$MESS["UF_PICTURE_RATIO"] = "Тип детальной картинки элемента";
$MESS["UF_LINKED_BLOG"] = "Связанные статьи";
$MESS["UF_BLOG_WIDE"] = "Номер строки товаров, после которой отображать связанные статьи (>768px)";
$MESS["UF_BLOG_BOTTOM"] = "Перенести связанные статьи из списка товаров в блок перед SEO-описанием";
$MESS["UF_BLOG_MOBILE"] = "Номер строки товаров, после которой отображать связанные статьи (<768px)";
$MESS["UF_MENU_BRANDS"] = "Связанные бренды в большом меню";
$MESS["UF_LINE_ELEMENT_CNT"] = "Количество элементов в строке";
?>